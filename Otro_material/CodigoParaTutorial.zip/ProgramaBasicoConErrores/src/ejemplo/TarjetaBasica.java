package ejemplo;

/**
 * Tarjeta de fidelidad basica.
 * Permite acumular el 5% de la cantidad gastada en cada compra
 * como descuento para compras sucesivas
 */
public class TarjetaBasica extends TarjetaFidelidad {
	// porcentaje de descuento de las tarjetas basicas: 5%
	private static final double PORCENTAJE_DESCUENTO_TARJETA_BASICA = 5;

	/**
	 * Construye una tarjeta
	 * @param dni DNI del propietario de la tarjeta
	 */
	public TarjetaBasica(String dni) {
		super(PORCENTAJE_DESCUENTO_TARJETA_BASICA, dni);
	}
	
}
