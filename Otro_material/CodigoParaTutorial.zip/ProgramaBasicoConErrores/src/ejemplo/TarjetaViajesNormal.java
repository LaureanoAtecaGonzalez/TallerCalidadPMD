package ejemplo;

/**
 * Tarjeta de viajes familiar.
 * Tarejeta de viajes normal que permite acumular un punto de viajes
 * por cada compra realizada.
 */
public class TarjetaViajesNormal extends TarjetaViajes {
	
	/**
	 * Construye una tarjeta de viajes normal
	 * @param dni DNI del propietario de la tarjeta
	 * @param direccion direccion del propietario de la tarjeta
	 */
	public TarjetaViajesNormal(String dni, String direccion) {
		super(dni, direccion);
	}
	
	/**
	 * Realiza una compra con la tarjeta. Como consecuencia de la compra se acumula
	 * el descuento y los puntos de viaje correspondientes
	 * @param gasto gasto correspondiente a la compra realizada
	 */
	@Override
	public void realizaCompra(double gasto) {
		super.realizaCompra(gasto);
		anyadePuntosViaje(1);	
	}

}
