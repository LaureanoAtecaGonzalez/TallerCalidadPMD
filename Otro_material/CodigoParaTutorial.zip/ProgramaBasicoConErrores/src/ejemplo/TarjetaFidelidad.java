package ejemplo;

/**
 * Superclase abstracta de la jerarquia de tarjetas de fidelidad del supermercado
 */
public abstract class TarjetaFidelidad {
	// porcentaje descuento acumulado en cada compra
	private final double PORCENTAJE_DESCUENTO_COMPRA;
	
	// DNI del propietario de la tarjeta
	private final String dni;
	
	// descuento acumulado por las compras realizadas
	private double descuentoAcumulado = 0.0;
	
	/**
	 * Crea una tarjeta
	 * @param porcentaje_descuento_compra porcentaje de descuento que la tarjeta
	 * acumulara en cada compra
	 * @param dni DNI del propietario de la tarjeta
	 */
	public TarjetaFidelidad(double porcentaje_descuento_compra, String dni) {
		this.dni = dni;
		PORCENTAJE_DESCUENTO_COMPRA = porcentaje_descuento_compra;
	}

	/**
	 * Realiza una compra con la tarjeta. Como consecuencia de la compra se acumula
	 * el descuento correspondiente
	 * @param gasto gasto correspondiente a la compra realizada
	 */
	public void realizaCompra(double gasto) {
		descuentoAcumulado += gasto * PORCENTAJE_DESCUENTO_COMPRA / 100;
	}
	
	/**
	 * Retorna el descuento acumulado
	 * @return descuento acumulado
	 */
	public double descuentoAcumulado() {
		return descuentoAcumulado;
	}
	
	/**
	 * Aplica el descuento acumulado al precio de compra. Disminuye
	 * el descuento acumulado en la tarjeta en la cantidad descontada en la
	 * compra.
	 * Si el precio de la compra es superior al descuento acumulado, el
	 * precio total de la compra se verá reducido en el descuento y el descuento pasará a ser cero.
	 * Si el precio es inferior al descuento acumulado, el descuento se ve reducido en el precio y
	 * el precio final de la compra es 0.
	 * 
	 * @param precioCompra precio de la compra sobre la que aplicar
	 * el descuento
	 * @return precio final de la compra una vez aplicado 
	 * el descuento.
	 */
	public double aplicaDescuento(double precioCompra) {
		if (descuentoAcumulado < precioCompra) {
			precioCompra -= descuentoAcumulado;
			descuentoAcumulado = 0;
		} else {
			descuentoAcumulado -= precioCompra;
			precioCompra = 0;
		}
		return precioCompra;
	}
	
	/**
	 * Retorna el DNI del propietario de la tarjeta
	 * @return DNI del propietario de la tarjeta
	 */
	public String dni() {
		return dni;
	}

}
