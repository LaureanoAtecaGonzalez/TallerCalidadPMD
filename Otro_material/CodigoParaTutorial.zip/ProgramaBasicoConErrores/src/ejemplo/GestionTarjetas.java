package ejemplo;

import java.util.List;
import fundamentos.*;

/**
 * Gestion de las tarjetas de fidelidad de los clientes de un supermercado
 *
 */
public class GestionTarjetas {

	/**
	 * Programa principal basado en menu
	 */
	public static void main(String[] args) {
		// opciones del menu
		final int NUEVA_TARJETA = 0, REALIZA_COMPRA = 1, CANJEA_PUNTOS = 2, 
		LISTADO_DESCUENTOS = 3;

		// variables auxiliares
		String dni;
		Lectura lect;
		TarjetaFidelidad tarjeta;

		// crea el registro con las tarjetas
		RegistroTarjetasFidelidad regTarjetas = new RegistroTarjetasFidelidad();

		// crea la ventana de menú
		Menu menu = new Menu("Tarjetas fidelidad");
		menu.insertaOpcion("Nueva tarjeta", NUEVA_TARJETA);
		menu.insertaOpcion("Realiza compra", REALIZA_COMPRA);
		menu.insertaOpcion("Canjea puntos viajes", CANJEA_PUNTOS);
		menu.insertaOpcion("Listado descuentos clientes", LISTADO_DESCUENTOS);
		int opcion;

		// lazo de espera de comandos del usuario
		while(true) {
			opcion = menu.leeOpcion();

			// realiza las acciones dependiendo de la opción elegida
			switch (opcion) {
			case NUEVA_TARJETA:
				lect = new Lectura("Datos nueva tarjeta");
				lect.creaEntrada("DNI cliente", "");
				lect.creaEntrada("Direccion cliente", "");
				lect.creaEntrada("Tipo Tarjeta: B | VN | VF", "B");
				lect.esperaYCierra();
				dni = lect.leeString("DNI cliente");
				String direccion = lect.leeString("Direccion cliente");
				String tipoTarjeta = lect.leeString("Tipo Tarjeta: B | VN | VF");
				
				// Crea la tarjeta del tipo apropiado
				tarjeta = null;
				if (tipoTarjeta.equals("B")) {
					tarjeta = new TarjetaBasica(dni);
				} else if (tipoTarjeta.equals("VN")) {
					tarjeta = new TarjetaViajesFamilia(dni, direccion);
				} else if (tipoTarjeta.equals("VF")) {
					tarjeta = new TarjetaViajesNormal(dni, direccion);
				}

				try {
					if (tarjeta!=null) {
						// anhade la tarjeta al registro
						regTarjetas.anhadeTarjeta(tarjeta);
					} else {
						mensaje("ERROR", "Tipo de tarjeta incorrecto, debe ser B, VN o VF");
					}
					
				} catch (RegistroTarjetasFidelidad.DNIYaExistente e) {
					mensaje("ERROR", "El cliente con DNI " + dni + " ya tiene una" +
					" tarjeta asignada");
				}
				break;

			case REALIZA_COMPRA:
				lect = new Lectura("Realiza compra");
				lect.creaEntrada("DNI cliente", "");
				lect.creaEntrada("Precio compra", "");
				lect.esperaYCierra();
				dni = lect.leeString("DNI cliente");
				double precioCompra = lect.leeDouble("Precio compra");
				
				// Realiza una compra con la tarjeta identificada por el DNI
				try {
					double precioFinal = regTarjetas.realizaCompra(dni, precioCompra);
					mensaje("Precio final", precioFinal + "€");
					
				} catch (RegistroTarjetasFidelidad.TarjetaNoExistente e) {
					mensaje("ERROR", "El cliente con DNI " + dni + " no tiene tarjeta");
				}				
				break;

			case CANJEA_PUNTOS:
				lect = new Lectura("Canjea puntos");
				lect.creaEntrada("DNI cliente", "");
				lect.creaEntrada("Puntos a canjear", "");
				lect.esperaYCierra();
				dni = lect.leeString("DNI cliente");
				int puntos = lect.leeInt("Puntos a canjear");
				
				// Resta los puntos canjeados de los acumulados en la tarjeta
				try {
					regTarjetas.canjeaPuntos(dni, puntos);
					
				} catch (RegistroTarjetasFidelidad.TarjetaNoExistente e) {
					mensaje("ERROR", "El cliente con DNI " + dni + " no tiene tarjeta");
					
				} catch (RegistroTarjetasFidelidad.TipoDeTarjetaIncorrecto e) {
					mensaje("ERROR", "El cliente con DNI " + dni + " no tiene tarjeta de viajes");
					
				} catch (TarjetaViajes.NoHaySuficientesPuntos e) {
					mensaje("ERROR", "El cliente con DNI " + dni + " no tiene suficientes puntos");
				}				
				break;

			case LISTADO_DESCUENTOS:
				// Obtiene una lista con todas las tarjetas del supermercado
				List<TarjetaFidelidad> tarjetas = regTarjetas.listaTarjetas();

				// muestra la informacion de las tarjetas en una CajaTexto del paquete fundamentos
				CajaTexto caja = new CajaTexto("Descuentos clientes", 10, 20);
				for(TarjetaFidelidad t: tarjetas) {
					caja.println(t.dni() + " -> " + t.descuentoAcumulado());
				}
				caja.esperaYCierra();
				break;
			}
		}
	}

	/**
	 * Metodo auxiliar que muestra un ventana de mensaje
	 * @param titulo titulo de la ventana
	 * @param txt texto contenido en la ventana
	 */
	private static void mensaje(String titulo, String txt) {
		Mensaje msj = new Mensaje(titulo);
		msj.escribe(txt);

	}

}
