package ejemplo;

/**
 * Tarjeta de viajes familiar.
 * Tarejeta de viajes que permite acumular un punto de viajes
 * por cada 50€ de compra.
 * 
 */
public class TarjetaViajesFamilia extends TarjetaViajes {
	// euros necesarios para conseguir un punto de viaje
	private static final double EUROS_POR_PUNTO = 50;
	
	/**
	 * Construye una tarjeta de viajes familiar
	 * @param dni DNI del propietario de la tarjeta
	 * @param direccion direccion del propietario de la tarjeta
	 */
	public TarjetaViajesFamilia(String dni, String direccion) {
		super(dni, direccion);
	}
	
	/**
	 * Realiza una compra con la tarjeta. Como consecuencia de la compra se acumula
	 * el descuento y los puntos de viaje correspondientes
	 * @param gasto gasto correspondiente a la compra realizada
	 */
	@Override
	public void realizaCompra(double gasto) {
		super.realizaCompra(gasto);
		
		// anyade un punto por cada 50€ de gasto
		anyadePuntosViaje((int) (gasto / EUROS_POR_PUNTO));	
	}

}
