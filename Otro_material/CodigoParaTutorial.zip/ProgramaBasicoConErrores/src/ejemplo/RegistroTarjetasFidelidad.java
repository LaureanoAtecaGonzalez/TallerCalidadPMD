package ejemplo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Registro con las tarjetas de fidelidad de los clientes de un
 * supermercado.
 */
public class RegistroTarjetasFidelidad {
	// tarjetas de fidelidad de los clientes
	private ArrayList<TarjetaFidelidad> tarjetas = new ArrayList<TarjetaFidelidad>();
	
	/**
	 * Lanzada por anhadeTarjeta si ya existe otra tarjeta con el mismo DNI 
	 * de cliente
	 */
	public static class DNIYaExistente extends RuntimeException {}
		
	/**
	 * Indica que no existe ninguna tarjeta con el DNI buscado
	 */
	public static class TarjetaNoExistente extends RuntimeException {}
	
	
	/**
	 * Lanzada por canjeaPuntos cuando la tarjeta sobre la que se desea realizar
	 * la operacion no es una tarjeta de viajes
	 */
	public static class TipoDeTarjetaIncorrecto extends RuntimeException {}
	
	/**
	 * Anhade una tarjeta al registro
	 * @param tarjeta tarjeta a anhadir
	 * @throws DNIYaExistente si ya existe otra tarjeta con el mismo DNI 
	 * de cliente
	 */
	public void anhadeTarjeta(TarjetaFidelidad tarjeta) {
		if (buscaTarjeta(tarjeta.dni()) != null) {
			throw new DNIYaExistente();
		}
		tarjetas.add(tarjeta);
	}
	
	/**
	 * Realiza una compra con la tarjeta del cliente con el DNI indicado
	 * @param dni DNI del cliente que realiza la compra
	 * @param precio precio de la compra realizada
	 * @return precio final de la compra una vez aplicado el posible descuento
	 * @throws TarjetaNoExistente si el cliente con el DNI indicado no tiene
	 * tarjeta
	 */
	public double realizaCompra(String dni, double precio) {
		TarjetaFidelidad t = buscaTarjeta(dni);
		if ( t == null) {
			throw new TarjetaNoExistente();
		}
		
		double precioFinal = t.aplicaDescuento(precio);
		t.realizaCompra(precio);
		return precioFinal;
	}
	
	/**
	 * Canjea el numero de puntos indicado de la tarjeta del cliente
	 * identificado por su DNI
	 * @param dni DNI del cliente
	 * @param puntos puntos a canjear
	 * @throws TarjetaNoExistente si el cliente con el DNI indicado no tiene
	 * tarjeta
	 * @throws TipoDeTarjetaIncorrecto si el cliente con el DNI indicado no tiene
	 * tarjeta de viajes
	 * @throws TarjetaViajes.NoHaySuficientesPuntos cuando la tarjeta no tiene
	 * suficientes puntos acumulados
	 */
	public void canjeaPuntos(String dni, int puntos) {
		TarjetaFidelidad t = buscaTarjeta(dni);
		if (t == null) {
			throw new TarjetaNoExistente();
		}
		
		if (!(t instanceof TarjetaViajes)) {
			throw new TipoDeTarjetaIncorrecto();
		}
		
		((TarjetaViajes) t).gastaPuntosViaje(puntos);	
	}
	
	/**
	 * Retorna una lista no modificable con las tarjetas registradas 
	 * @return ista no modificable con las tarjetas registradas 
	 */
	public List<TarjetaFidelidad> listaTarjetas() {
		return Collections.unmodifiableList(tarjetas);
	}
	
	/**
	 * Busca la tarjeta que tiene como propietario el cliente
	 * con el DNI indicado
	 * @param dni DNI del cliente buscado
	 * @return tarjeta que tiene como propietario el cliente
	 * con el DNI indicado o null si no existe ninguna tarjeta
	 * con ese DNI
	 */
	private TarjetaFidelidad buscaTarjeta(String dni) {
		for(TarjetaFidelidad t: tarjetas) {
			if (t.dni().equals(dni)) {
				return t;
			}
		}
		return null;
	}

}
