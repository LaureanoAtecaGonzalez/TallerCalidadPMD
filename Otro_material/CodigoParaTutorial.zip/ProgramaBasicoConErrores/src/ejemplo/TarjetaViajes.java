package ejemplo;

/**
 * Clase abstracta que engloba el comportamiento comun de los distintos
 * tipos de tarjetas de viajes.
 * Realiza la gestion de los puntos de viaje.
 * Define el procentaje de descuento de las tarjetas de viaje (4%).
 * 
 */
public abstract class TarjetaViajes extends TarjetaFidelidad {
	// porcentaje de descuento acumulado por compra de las tarjetas de viajes
	private static final double PORCENTAJE_DESCUENTO_TARJETA_VIAJES = 4;
	
	// direccion del propietario de la tarjeta
	private final String direccion;
	
	// puntos de viaje acumulados en la tarjeta
	private int puntosViaje;
	
	/**
	 * Lanzada por gastaPuntosViaje cuando los puntos acumulados no son
	 * suficientes.
	 */
	public static class NoHaySuficientesPuntos extends RuntimeException {}

	/**
	 * Construye una tarjeta de viajes
	 * @param dni DNI del propietario de la tarjeta
	 * @param direccion direccion del propietario de la tarjeta
	 */
	public TarjetaViajes(String dni, String direccion) {
		super(PORCENTAJE_DESCUENTO_TARJETA_VIAJES, dni);
		this.direccion = direccion;
	}
	
	/**
	 * Retorna los puntos de viaje acumulados en la tarjeta
	 * @return puntos de viaje acumulados en la tarjeta
	 */
	public int puntosViajeAcumulados() {
		return puntosViaje;
	}
	
	/**
	 * Anhade la cantidad indicada de puntos de viaje a los puntos
	 * de viaje acumulados en la tarjeta
	 * @param ptos puntos de viaje a anhadir a los ya acumulados
	 */
	public void anyadePuntosViaje(int ptos) {
		puntosViaje += ptos;
	}
	
	/**
	 * Gasta los puntos de viaje indicados restandolos de los puntos acumulados
	 * @param ptos puntos de viaje a gastar
	 * @throws NoHaySuficientesPuntos si el numero de puntos acumulado es menor
	 * que la cantidad que se quiere gastar
	 */
	public void gastaPuntosViaje(int ptos) {
		if (puntosViaje < ptos) {
			throw new NoHaySuficientesPuntos();
		}
		puntosViaje -= ptos;
	}

	/**
	 * Retorna la direccion del cliente propietario de la tarjeta
	 * @return direccion del cliente propietario de la tarjeta
	 */
	public String direccion() {
		return direccion;
	}

}
